package com.example.foodapp.Fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView // Ensure this import is correct
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.foodapp.R
import com.example.foodapp.adaptar.MenuAdapter
import com.example.foodapp.databinding.FragmentSearchBinding

class SearchFragment : Fragment() {
    private lateinit var binding: FragmentSearchBinding
    private lateinit var adapter: MenuAdapter
    private val originalMenuFoodName = listOf("Burger", "Sandwich", "Momo", "Pizza", "Noodles", "Pasta", "Fries", "Salad")
    private val originalMenuItemPrices = listOf("$5", "$7", "$8", "$10", "$9", "$12", "$4", "$6")
    private val originalMenuImages = listOf(
        R.drawable.menu1, R.drawable.menu4, R.drawable.photo2, R.drawable.photo3,
        R.drawable.photo2, R.drawable.photo3, R.drawable.photo2, R.drawable.photo3
    )

    // Mutable lists to hold filtered data
    private var filteredMenuFoodName = originalMenuFoodName.toMutableList()
    private var filteredMenuItemPrices = originalMenuItemPrices.toMutableList()
    private var filteredMenuImages = originalMenuImages.toMutableList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSearchBinding.inflate(inflater, container, false)

        adapter = MenuAdapter(filteredMenuFoodName, filteredMenuItemPrices, filteredMenuImages,requireContext())
        binding.menuRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        binding.menuRecyclerView.adapter = adapter

        // Set up the search view
        setupSearchView()
        return binding.root
    }

    private fun setupSearchView() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false // Return false to indicate query was not handled
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterMenuItems(newText)
                return true // Return true to indicate text change was handled
            }
        })
    }

    private fun filterMenuItems(query: String?) {
        if (query.isNullOrEmpty()) {
            // Reset to original list if query is empty
            filteredMenuFoodName = originalMenuFoodName.toMutableList()
            filteredMenuItemPrices = originalMenuItemPrices.toMutableList()
            filteredMenuImages = originalMenuImages.toMutableList()
        } else {
            val lowerCaseQuery = query.toLowerCase()
            filteredMenuFoodName.clear()
            filteredMenuItemPrices.clear()
            filteredMenuImages.clear()

            for (i in originalMenuFoodName.indices) {
                if (originalMenuFoodName[i].toLowerCase().contains(lowerCaseQuery)) {
                    filteredMenuFoodName.add(originalMenuFoodName[i])
                    filteredMenuItemPrices.add(originalMenuItemPrices[i])
                    filteredMenuImages.add(originalMenuImages[i])
                }
            }
        }
        adapter.updateData(filteredMenuFoodName, filteredMenuItemPrices, filteredMenuImages)
    }
}
