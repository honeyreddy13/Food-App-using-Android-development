package com.example.foodapp.adaptar

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.recyclerview.widget.RecyclerView
import com.example.foodapp.DetailsActivity
import com.example.foodapp.databinding.MenuItemBinding

class MenuAdapter(
    private var menuItemsNames: List<String>,
    private var menuItemPrice: List<String>,
    private var menuImages: List<Int>,
    private val requireContext: Context
) : RecyclerView.Adapter<MenuAdapter.MenuViewHolder>() {
private val itemClickListener: AdapterView.OnItemClickListener? = null
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
        val binding = MenuItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MenuViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
        holder.bind(position)
    }

    override fun getItemCount(): Int = menuItemsNames.size

    inner class MenuViewHolder(private val binding: MenuItemBinding) : RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    itemClickListener?.onItemClick(position)
                }
                val intent = Intent(requireContext,DetailsActivity::class.java)
                intent.putExtra("MenuItemName",menuItemsNames.get(position))
                intent.putExtra("MenuItemImage",menuImages.get(position))
                requireContext.startActivity(intent)
            }
        }
        fun bind(position: Int) {
            binding.apply {
                menuFoodName.text = menuItemsNames[position]
                menuPrice.text = menuItemPrice[position]
                menuImage.setImageResource(menuImages[position])


            }
        }
    }

    // Method to update the adapter data
    fun updateData(newMenuItemsNames: List<String>, newMenuItemPrice: List<String>, newMenuImages: List<Int>) {
        menuItemsNames = newMenuItemsNames
        menuItemPrice = newMenuItemPrice
        menuImages = newMenuImages
        notifyDataSetChanged() // Refresh the RecyclerView after data change
    }
    interface OnItemClickListener {
        fun onItemClick(position: Int)


    }
}

private fun AdapterView.OnItemClickListener?.onItemClick(position: Int) {

}



