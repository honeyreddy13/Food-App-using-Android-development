package com.example.foodapp.adaptar

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.foodapp.databinding.BuyAgainItemBinding

class BuyAgainAdapter(
    private val buyAgainFoodNames: List<String>,
    private val buyAgainFoodPrices: List<String>,
    private val buyAgainFoodImages: List<Int>
) : RecyclerView.Adapter<BuyAgainAdapter.BuyAgainViewHolder>() {

    // ViewHolder for holding item views
    inner class BuyAgainViewHolder(private val binding: BuyAgainItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(name: String, price: String, imageRes: Int) {
            binding.apply {
                buyagainfoodName.text = name
                buyagainfoodPrice.text = price
                buyagainfoodImage.setImageResource(imageRes)

                // Optional: Set an onClickListener if you want to handle clicks on the button
                cardView2.setOnClickListener {
                    // Handle click event for "Buy Again" button here
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BuyAgainViewHolder {
        val binding = BuyAgainItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BuyAgainViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BuyAgainViewHolder, position: Int) {
        // Bind data to the ViewHolder
        holder.bind(buyAgainFoodNames[position], buyAgainFoodPrices[position], buyAgainFoodImages[position])
    }

    override fun getItemCount(): Int {
        return buyAgainFoodNames.size
    }
}
