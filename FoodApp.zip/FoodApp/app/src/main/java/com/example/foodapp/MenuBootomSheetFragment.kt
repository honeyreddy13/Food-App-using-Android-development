package com.example.foodapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.foodapp.adaptar.MenuAdapter
import com.example.foodapp.databinding.FragmentMenuBootomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class MenuBottomSheetFragment : BottomSheetDialogFragment() {
    private lateinit var binding: FragmentMenuBootomSheetBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMenuBootomSheetBinding.inflate(inflater, container, false)
        binding.buttonBack.setOnClickListener {
       dismiss()}
        // Dummy menu data
        val menuFoodNames = listOf("Burger", "Sandwich", "Momo", "Pizza", "Noodles", "Pasta", "Fries", "Salad")
        val menuItemPrices = listOf("$5", "$7", "$8", "$10", "$9", "$12", "$4", "$6")
        val menuImages = listOf(
            R.drawable.menu1, R.drawable.menu4, R.drawable.photo2, R.drawable.photo3,
            R.drawable.photo2, R.drawable.photo3, R.drawable.photo2, R.drawable.photo3
        )

        // Setting up the RecyclerView with the MenuAdapter (replaces CartAdapter)
        val adapter = MenuAdapter(ArrayList(menuFoodNames), ArrayList(menuItemPrices), ArrayList(menuImages),requireContext())
        binding.menuRecyclerView.layoutManager = LinearLayoutManager(requireContext()) // Updated ID for RecyclerView
        binding.menuRecyclerView.adapter = adapter // Set the new menu adapter

        return binding.root
    }

    companion object {
        @JvmStatic
        fun newInstance(): MenuBottomSheetFragment {
            return MenuBottomSheetFragment()
        }
    }
}
