package com.example.foodapp

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.foodapp.databinding.ActivityChooseLocationBinding

class ChooseLocationActivity : AppCompatActivity() {
    private val binding: ActivityChooseLocationBinding by lazy {
        ActivityChooseLocationBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)

        val locationList: Array<String> = arrayOf("Jalandhar", "Delhi", "Lucknow", "Varanasi", "Ghazipur", "Gahmar")
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, locationList)
        val autoCompleteTextView: AutoCompleteTextView = binding.listofLocation
        autoCompleteTextView.setAdapter(adapter)

        // Set the item click listener
        autoCompleteTextView.setOnItemClickListener { parent, view, position, id ->
            val selectedLocation = parent.getItemAtPosition(position).toString()
            Toast.makeText(this, "Selected Location: $selectedLocation", Toast.LENGTH_SHORT).show() // Optional: Show a toast message

            // Start MainActivity after selecting a location
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // Optional: Call finish() if you don't want to go back to this activity
        }
    }
}
